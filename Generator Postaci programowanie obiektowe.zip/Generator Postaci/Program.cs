﻿using System;   // losowanie i konsola
using System.Collections.Generic;  // listy i słowniki 
using System.Drawing;
using System.Linq;  // filtrowanie i sortowanie 
using System.IO; // Do obsługi plików

class GeneratorBadacza // tu jest cale mięsko 
{
    static Random random = new Random();

    static void Main(string[] args)
    {
        Badacz postac = Generator(); // Generowanie postaci
        wyswietlanie(postac); // Wyświetlanie danych postaci w konsoli
        ZapiszDoPliku(postac); // Zapis danych postaci do pliku
    }

    public static Badacz Generator()
    {
        // Losowanie imienia i nazwiska
        string[] imiona = { "John", "Jane", "Edward", "Emily", "Victoria", "Anna", "Robert", "Sarah","Julie","Cathrene","Anabelle","Rose","Tom","Samuel","Johan","Arnold","Chuck" };  //lista
        string[] nazwiska = { "Smith", "Doe", "Brown", "Johnson", "Taylor", "Williams", "Davis", "Clark","Clarkson","Norris","Goldberg","Braun" }; //lista
        string imie = imiona[random.Next(imiona.Length)];  // losuje jedno z listy 
        string nazwisko = nazwiska[random.Next(nazwiska.Length)]; // losuje jedno z listy 

        // Losowanie profesji
        Profesja zawód = Lista_profesji.Losowy_zawód();

        // Atrybuty podstawowe
        int S = Losowanko(3, 6);
        int ZR = Losowanko(3, 6);
        int KON = Losowanko(3, 6);
        int WYG = Losowanko(3, 6);
        int INT = Losowanko(2, 6, 6);
        int WYK = Losowanko(2, 6, 6);
        int BC = Losowanko(2, 6, 6);
        int MOC = Losowanko(3, 6);

        // Cechy dodatkowe
        int Poczytalnosc = MOC;
        int PM = MOC / 5;
        int Fart = Losowanko(3, 6);
        int HP = (KON + BC) / 10;

        // Obliczanie Krzepy i Modyfikatora Obrażeń
        int SBC = S + BC;
        (string BonusDMG, int Krzepa) = PoliczKrzepe(SBC);

        // Majętność i umiejętności
        int maje = random.Next(zawód.Majętność.Item1, zawód.Majętność.Item2 + 1);
        Dictionary<string, int> Umki = RozdzielUmki(zawód, WYK * 4, maje);

        // Automatyczne przypisanie wartości do Języka Ojczystego i Uniku
        Umki["Język Ojczysty"] = WYK; // Wartość WYK
        Umki["Unik"] = ZR / 2;      // Połowa ZR

        // Punkty hobby
        int hobby = INT * 2;
        Umki = RozdzielHobby(Umki, hobby);

        return new Badacz
        {
            Imie = imie,
            Nazwisko = nazwisko,
            Zawód = zawód.Nazwa,
            S = S,
            ZR = ZR,
            KON = KON,
            WYG = WYG,
            INT = INT,
            WYK = WYK,
            BC = BC,
            MOC = MOC,
            Poczytalnosc = Poczytalnosc,
            PM = PM,
            Fart = Fart,
            HP = HP,
            BonusDMG = BonusDMG,
            Krzepa = Krzepa,
            Umki = Umki,
            Majętność = maje
        };

    }
    public static int Losowanko(int rzuty, int strony, int bonus = 0)  // symulacja rzutu kostką
    {
        int total = 0;
        for (int i = 0; i < rzuty; i++)
        {
            total += random.Next(1, strony + 1);
        }
        return (total + bonus) * 5;
    }
    public static (string, int) PoliczKrzepe(int SBC) // określanie bonusu do obrażeń
    {
        if (SBC <= 64) return ("-2", -2);
        if (SBC <= 84) return ("-1", -1);
        if (SBC <= 124) return ("0", 0);
        if (SBC <= 164) return ("+1K4", 1);
        return ("+1K6", 2);
    }
    public static Dictionary<string, int> RozdzielUmki(Profesja zawód, int Umki, int maje)  //rodzielenie punktów na umiejętności zawodowe
    {
        Dictionary<string, int> skills = Lista_skilli.wezUmki();
        List<string> SkilleZawodowe = new List<string>(zawód.Skille);

        foreach (var skill in SkilleZawodowe)
        {
            if (skill == "Majętność")
            {
                skills[skill] = maje;
            }
        }

        while (Umki > 0)
        {
            string LosowySkill = SkilleZawodowe[random.Next(SkilleZawodowe.Count)];
            int maxValue = LosowySkill == "Majętność" ? maje : 75;

            if (skills[LosowySkill] < maxValue)
            {
                int wolne_pkt = Math.Min(Umki, random.Next(1, maxValue - skills[LosowySkill] + 1));
                skills[LosowySkill] += wolne_pkt;
                Umki -= wolne_pkt;
            }
        }

        return skills;
    }
    public static Dictionary<string, int> RozdzielHobby(Dictionary<string, int> skills, int PKT_hobby)
    {
        List<string> hobbySkills = skills.Keys
            .Where(skill => skill != "Mity Cthulhu" && skill != "Majętność")
            .ToList();

        List<string> wybranehobby = hobbySkills.OrderBy(x => random.Next()).Take(4).ToList();

        while (PKT_hobby > 0)
        {
            string randomSkill = wybranehobby[random.Next(wybranehobby.Count)];
            int maxValue = 75;

            if (skills[randomSkill] < maxValue)
            {
                int wolne_pkt = Math.Min(PKT_hobby, random.Next(1, maxValue - skills[randomSkill] + 1));
                skills[randomSkill] += wolne_pkt;
                PKT_hobby -= wolne_pkt;
            }
            if (hobbySkills.All(skill => skills[skill] >= maxValue))
                break;

        }

        return skills;
    } // rodzielenie punktów na umiejętności z hobby


    public static void wyswietlanie(Badacz postac)
    {
        Console.Clear();
        Console.WriteLine("=== Postać Zew Cthulhu ===");
        Console.WriteLine($"Imię i nazwisko: {postac.Imie} {postac.Nazwisko}");
        Console.WriteLine($"Profesja: {postac.Zawód}");
        Console.WriteLine($"Majętność: {postac.Majętność}");
        Console.WriteLine("==========================");
        Console.WriteLine($"Siła: {postac.S}");
        Console.WriteLine($"Zręczność: {postac.ZR}");
        Console.WriteLine($"Budowa Ciała: {postac.BC}");
        Console.WriteLine($"Kondycja: {postac.KON}");
        Console.WriteLine($"Wygląd: {postac.WYG}");
        Console.WriteLine($"Inteligencja: {postac.INT}");
        Console.WriteLine($"Wykształcenie: {postac.WYK}");
        Console.WriteLine($"Moc: {postac.MOC}");
        Console.WriteLine($"Poczytalność: {postac.Poczytalnosc}");
        Console.WriteLine($"Punkty Magii: {postac.PM}");
        Console.WriteLine($"Punkty Szczęścia: {postac.Fart}");
        Console.WriteLine($"Punkty Wytrzymałości: {postac.HP}");
        Console.WriteLine($"Krzepa: {postac.Krzepa} ({postac.BonusDMG})");
        Console.WriteLine("\nUmiejętności:");
        foreach (var Umka in postac.Umki.Where(s => s.Value > Lista_skilli.wezUmki()[s.Key]).OrderBy(s => s.Key))
        {
            Console.WriteLine($"{Umka.Key}: {Umka.Value}%");
        }

        Console.WriteLine("\nNaciśnij dowolny klawisz, aby zakończyć...");
        Console.ReadKey();
    }

    public static void ZapiszDoPliku(Badacz postac)
    {
        string folderProjektu = AppDomain.CurrentDomain.BaseDirectory; // Ścieżka folderu projektu
        string folderBadacze = Path.Combine(folderProjektu, "Badacze");
        if (!Directory.Exists(folderBadacze))
        {
            Directory.CreateDirectory(folderBadacze);
        }

        string nazwaPliku = $"{postac.Imie}_{postac.Nazwisko}_statystyki.txt";
        string sciezkaPliku = Path.Combine(folderBadacze, nazwaPliku);
        using (StreamWriter sw = new StreamWriter(sciezkaPliku))
        {
            sw.WriteLine("=== Postać Zew Cthulhu ===");
            sw.WriteLine($"Imię i nazwisko: {postac.Imie} {postac.Nazwisko}");
            sw.WriteLine($"Profesja: {postac.Zawód}");
            sw.WriteLine($"Majętność: {postac.Majętność}");
            sw.WriteLine("==========================");
            sw.WriteLine($"Siła: {postac.S}");
            sw.WriteLine($"Zręczność: {postac.ZR}");
            sw.WriteLine($"Budowa Ciała: {postac.BC}");
            sw.WriteLine($"Kondycja: {postac.KON}");
            sw.WriteLine($"Wygląd: {postac.WYG}");
            sw.WriteLine($"Inteligencja: {postac.INT}");
            sw.WriteLine($"Wykształcenie: {postac.WYK}");
            sw.WriteLine($"Moc: {postac.MOC}");
            sw.WriteLine($"Poczytalność: {postac.Poczytalnosc}");
            sw.WriteLine($"Punkty Magii: {postac.PM}");
            sw.WriteLine($"Punkty Szczęścia: {postac.Fart}");
            sw.WriteLine($"Punkty Wytrzymałości: {postac.HP}");
            sw.WriteLine($"Krzepa: {postac.Krzepa} ({postac.BonusDMG})");
            sw.WriteLine("\nUmiejętności:");
            foreach (var Umka in postac.Umki.Where(s => s.Value > Lista_skilli.wezUmki()[s.Key]).OrderBy(s => s.Key))
            {
                sw.WriteLine($"{Umka.Key}: {Umka.Value}%");
            }
        }
        Console.WriteLine($"Dane postaci zostały zapisane do pliku: {nazwaPliku}");
    }
}

public class Badacz //tu sa trzymane statystyki Badacza itd
{
    public string Imie { get; set; } = "";
    public string Nazwisko { get; set; } = ""; 
    public string Zawód { get; set; } = "";
    public int S { get; set; }
    public int ZR { get; set; }
    public int KON { get; set; }
    public int WYG { get; set; }
    public int INT { get; set; }
    public int WYK { get; set; }
    public int BC { get; set; }
    public int MOC { get; set; }
    public int Poczytalnosc { get; set; }
    public int PM { get; set; }
    public int Fart { get; set; }
    public int HP { get; set; }
    public string BonusDMG { get; set; } = ""; // Domyślnie pusty string
    public int Krzepa { get; set; }
    public int Majętność { get; set; }
    public Dictionary<string, int> Umki { get; set; } = new Dictionary<string, int>(); // Domyślna pusta mapa

}
public class Profesja //model danych, który reprezentuje pojedynczy zawód
{
    public string Nazwa { get; set; } = ""; // Domyślnie pusta nazwa
    public List<string> Skille { get; set; } = new List<string>(); // Domyślnie pusta lista umiejętności
    public (int, int) Majętność { get; set; }
}
public static class Lista_profesji //pomocnicza klasa do zarządzania i losowania zawodów
{
    private static Random random = new Random();

    private static List<Profesja> zawody = new List<Profesja>
    {
        new Profesja
        {
            Nazwa = "Detektyw",
            Skille = new List<string> { "Charakteryzacja", "Prawo", "Psychologia", "Spostrzegawczość", "Gadanina", "Fotografia", "Bijatyka", "Nasłuchiwanie" },
            Majętność = (30, 60)
        },
        new Profesja
        {
            Nazwa = "Naukowiec",
            Skille = new List<string> { "Spostrzegawczość", "Język Obcy", "Fizyka", "Geologia", "Matematyka", "Okultyzm", "Korzystanie z Bibliotek", "Perswazja" },
            Majętność = (40, 70)
        },
        new Profesja
        {
            Nazwa = "Fanatyk",
            Skille = new List<string> { "Historia", "Język Obcy", "Ukrywanie", "Gadanina", "Mity Cthulhu", "Okultyzm", "Korzystanie z Bibliotek", "Perswazja" },
            Majętność = (0, 30)
        },
        new Profesja
        {
            Nazwa = "Dziennikarz",
            Skille = new List<string> { "Język Ojczysty", "Korzystanie z Bibliotek", "Historia", "Psychologia", "Fotografia", "Urok Osobisty", "Broń Krótka", "Perswazja" },
            Majętność = (40, 50)
        }



    };

    public static Profesja Losowy_zawód()
    {
        return zawody[random.Next(zawody.Count)];
    }
}
public static class Lista_skilli // lista wszystkich umiejetnosci i ich wartosci
{
    public static Dictionary<string, int> wezUmki()
    {
        return new Dictionary<string, int>
        {
            { "Aktorstwo", 5 }, { "Antropologia", 1 }, { "Archeologia", 1 }, { "Astronomia", 1 }, { "Bijatyka", 25 },
            { "Biologia", 1 }, { "Broń Artyleryjska", 1 }, { "Broń Ciężka", 10 }, { "Broń Krótka", 20 }, { "Charakteryzacja", 5 },
            { "Chemia", 1 }, { "Czytanie z Ruchu Warg", 1 }, { "Elektronika", 1 }, { "Elektryka", 10 }, { "Fałszerstwo", 5 },
            { "Farmacja", 1 }, { "Fizyka", 1 }, { "Fotografia", 5 }, { "Gadanina", 5 }, { "Garota", 15 },
            { "Geologia", 1 }, { "Hipnoza", 1 }, { "Historia", 5 }, { "Inżynieria", 1 }, { "Jeździectwo", 5 }, {"Matematyka", 1},
            { "Język Obcy", 1 }, { "Język Ojczysty", 0 }, { "Korzystanie z Bibliotek", 20 }, { "Kryminalistyka", 1 },
            { "Medycyna", 1 }, { "Meteorologia", 1 }, { "Mity Cthulhu", 0 }, { "Nasłuchiwanie", 20 }, { "Nawigacja", 10 },
            { "Okultyzm", 5 }, { "Perswazja", 10 }, { "Pierwsza Pomoc", 30 }, { "Pływanie", 20 }, { "Prawo", 5 },
            { "Psychologia", 10 }, { "Rzucanie", 20 }, { "Spostrzegawczość", 25 }, { "Ukrywanie", 20 },
            { "Unik", 0 }, { "Urok Osobisty", 15 }, { "Wiedza Tajemna", 1 }, { "Wspinaczka", 20 }
        };
    }
}
